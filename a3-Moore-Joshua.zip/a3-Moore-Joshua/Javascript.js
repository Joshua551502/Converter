function convertCtoF() {
    let input = document.getElementById("input").value;
    let result = (input * 9 / 5) + 32;
    document.getElementById("output").innerHTML = result.toFixed(2) + "°F";
}

function convertFtoC() {
    let input = document.getElementById("input").value;
    let result = (input - 32) * 5 / 9;
    document.getElementById("output").innerHTML = result.toFixed(2) + "°C";
}  

function convertFtoM() {
    // convert feet to meters code here
    let input = document.getElementById("input").value;
    let result = input * 0.3048;
    document.getElementById("output").innerHTML = result.toFixed(2) + "m";
  }
  
  function convertMtoF() {
    // convert meters to feet code here
    let input = document.getElementById("input").value;
    let result = input / 0.3048;
    document.getElementById("output").innerHTML = result.toFixed(2) + "ft";
  }
  
  function convertItoC() {
    // convert inches to centimeters code here
    let input = document.getElementById("input").value;
    let result = input * 2.54;
    document.getElementById("output").innerHTML = result.toFixed(2) + "cm";
  }
  
  function convertCtoI() {
    // convert centimeters to inches code here
    let input = document.getElementById("input").value;
    let result = input / 2.54;
    document.getElementById("output").innerHTML = result.toFixed(2) + "″";
  }
  
  function convertPtoK() {
    // convert pounds to kilograms code here
    let input = document.getElementById("input").value;
    let result = input * 0.453592;
    document.getElementById("output").innerHTML = result.toFixed(2) + "kg";
  }
  
  function convertKtoP() {
    // convert kilograms to pounds code here
    let input = document.getElementById("input").value;
    let result = input / 0.453592;
    document.getElementById("output").innerHTML = result.toFixed(2) + "lbs";
  }
  
  function clearInput() {
    // clear input code here
    document.getElementById("output").innerHTML = "";
  }
  
